function playAnimation1() {
    var video = document.getElementById('animation1Video');
    video.play();
}

function playAnimation2() {
    var video = document.getElementById('animation2Video');
    video.play();
}